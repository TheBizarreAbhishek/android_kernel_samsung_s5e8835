# Porting Mali KMD r54p3 -> Bizarre Kernel (s5e8835, android13-5.15)

NON COMPILATO. Controlli fatti solo in modo statico (vedi sotto).

## 1. Copia i file nel tuo fork (android_kernel_samsung_s5e8835)
- drivers/gpu/arm/v_r54p3/   (nuova cartella)
- drivers/gpu/arm/Kbuild     (sostituisce l'originale: aggiunge R54P3)
- drivers/gpu/arm/Kconfig    (sostituisce l'originale: aggiunge R54P3)

## 2. Servono ANCHE gli header dal repo Floppy (NON inclusi qui)
Dal repo flop_s5e8825_kernel (branch floppy-new) copia nel tuo kernel:
- include/linux/v_r54p3/
- include/uapi/gpu/arm/v_r54p3/
L'elenco dei 17 header richiesti e' in NEEDED_HEADERS.txt.

## 3. Defconfig
- togli CONFIG_MALI_DDK_VALHALL_R38P1 (o R44P0) e metti CONFIG_MALI_DDK_VALHALL_R54P3=y
- il resto (CONFIG_MALI_MIDGARD=y, exynos ecc.) resta com'e'

## 4. Cosa e' stato cambiato rispetto alla copia di Floppy
- Kbuild di v_r54p3 riscritto nello stile Bizarre (un solo mali_kbase, piattaforma exynos inclusa da ../exynos/Kbuild)
- tutti i Kbuild delle sottocartelle: mali_kbase_r54p3-y -> mali_kbase-y
- tolto mali_no_export.h e il controllo mali_selected_version in mali_kbase_core_linux.c
- Kconfig di v_r54p3 = quello di r38p1 di Bizarre + LARGE_PAGE_SUPPORT, MALI_TRACE_POWER_GPU_WORK_PERIOD, MALI_CORESIGHT
- la cartella exynos NON e' toccata

## 5. Verifiche statiche fatte
- tutti i simboli mali_exynos_* usati da r54p3 esistono nel tuo exynos
- i campi kbase usati dal tuo exynos (pm.backend.metrics.*, protected_*, kctx_list, katom->start_timestamp ecc.) esistono in r54p3
- i membri di kbase_pm_callback_conf / kbase_platform_funcs_conf / kbase_clk_rate_trace_op_conf coincidono
- ogni .o elencato nei Kbuild ha il suo .c
- per l'8835 il secure rendering usa il percorso ARM+HVC, non il legacy (che userebbe kbase_reg_read/write, assenti in r54p3)

## 6. Rischi noti
- errori di compilazione possibili (non ho potuto compilare)
- le modifiche di Floppy a exynos (utilizzo GPU per job slot, memory usage) NON sono portate
- dtbo/frequenze: non verificati con r54p3
